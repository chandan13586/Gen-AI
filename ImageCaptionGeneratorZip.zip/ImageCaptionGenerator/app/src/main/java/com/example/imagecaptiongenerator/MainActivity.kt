package com.example.imagecaptiongenerator
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var selectedImageView: ImageView
    private lateinit var captionTextView: TextView
    private var selectedImageUri: Uri? = null
    private val PICK_IMAGE_REQUEST = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        selectedImageView = findViewById(R.id.selected_image_view)
        captionTextView = findViewById(R.id.caption_text)

        val selectImageButton = findViewById<Button>(R.id.select_image_button)
        val generateCaptionButton = findViewById<Button>(R.id.generate_caption_button)

        // Set up the image selection button
        selectImageButton.setOnClickListener {
            openImagePicker()
        }

        // Set up the caption generation button
        generateCaptionButton.setOnClickListener {
            if (selectedImageUri != null) {
                generateCaptionForImage(selectedImageUri!!)
            } else {
                Toast.makeText(this, "Please select an image first", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Open image picker to select an image
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    // Handle the result of the image picker
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.data != null) {
            selectedImageUri = data.data
            try {
                // Display the selected image in the ImageView
                val bitmap: Bitmap = MediaStore.Images.Media.getBitmap(contentResolver, selectedImageUri)
                selectedImageView.setImageBitmap(bitmap)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    // Generate caption for the selected image
    private fun generateCaptionForImage(imageUri: Uri) {
        Log.d("main","generateCaptionForImage");
        // Convert the imageUri to a file path or describe the image to use as a prompt for OpenAI
        val prompt = "Describe the image in detail"

        val request = OpenAIRequest(
            model = "gpt-3.5-turbo",  // The model you're using
            prompt = prompt,             // Replace with your image description prompt
            max_tokens = 200
        )

        // Fetch the API service
        val apiService = RetrofitInstance.apiService
        val apiKey = "Bearer sk-XoQI1qg8Pdf44h_3e_LFIelD9BgtlbJinIdHNL9UBTT3BlbkFJ8daEKOJR1JQsGKm0f1banB8rSJvauFFtZBS8opiPAA"  // Replace with your actual OpenAI API key

        // Make the API call
        apiService.getCaption(apiKey, request).enqueue(object : Callback<OpenAIApiResponse> {
            override fun onResponse(call: Call<OpenAIApiResponse>, response: Response<OpenAIApiResponse>) {
                if (response.isSuccessful) {
                    val apiResponse = response.body()
                    val generatedText = apiResponse?.choices?.get(0)?.text ?: "No response text"
                    captionTextView.text = generatedText
                    Toast.makeText(this@MainActivity, "Caption generated", Toast.LENGTH_SHORT).show()
                    Log.d("MainActivity", "Response: $generatedText")
                } else {
                    Log.e("MainActivity", "Error: ${response.code()} - ${response.errorBody()?.string()}")
                }
            }

            override fun onFailure(call: Call<OpenAIApiResponse>, t: Throwable) {
                Log.e("MainActivity", "API Call failed: ${t.message}")
                Toast.makeText(this@MainActivity, "Failed to generate caption", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
