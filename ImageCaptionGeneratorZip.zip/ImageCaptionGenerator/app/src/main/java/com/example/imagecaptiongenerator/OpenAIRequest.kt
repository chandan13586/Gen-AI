package com.example.imagecaptiongenerator

data class OpenAIRequest(
    val model: String,    // The OpenAI model you're using, e.g., "text-davinci-003"
    val prompt: String,   // The input text or prompt
    val max_tokens: Int,  // Maximum number of tokens in the response
    val temperature: Double? = 0.7,  // Optional, controls the randomness
    val top_p: Double? = 1.0,        // Optional, controls diversity
    val n: Int? = 1                 // Number of completions to generate
)

