package com.example.imagecaptiongenerator

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

interface OpenAIApi {
    @POST("v1/completions")
    @Headers("Content-Type: application/json")
    fun getCaption(
        @Header("Authorization") authorization: String,  // API key goes here
        @Body request: OpenAIRequest
    ): Call<OpenAIApiResponse>
}
