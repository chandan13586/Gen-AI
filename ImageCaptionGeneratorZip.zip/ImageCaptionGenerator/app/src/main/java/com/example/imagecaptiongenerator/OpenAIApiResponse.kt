package com.example.imagecaptiongenerator

data class OpenAIApiResponse(
    val choices: List<Choice>
)

data class Choice(
    val text: String
)
